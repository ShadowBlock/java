package src.assessment;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class Toy {
    private String toyName;
    private String toyColor;
}
