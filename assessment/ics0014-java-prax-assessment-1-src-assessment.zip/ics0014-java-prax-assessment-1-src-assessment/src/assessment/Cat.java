package src.assessment;

import lombok.AllArgsConstructor;
import lombok.Data;

import java.util.ArrayList;
import java.util.List;

@Data
@AllArgsConstructor
public class Cat {
    private String name;
    private String breed;
    private String furColor;
    private String eyeColor;
    private List<Toy> favoriteToys;


    // Constructor without favorite toy, used for part 2 of assessment
    public Cat(String inputName, String inputBreed, String inputFurColor, String inputEyeColor) {
        this.name = inputName;
        this.breed = inputBreed;
        this.furColor = inputFurColor;
        this.eyeColor = inputEyeColor;
        this.favoriteToys = new ArrayList<>();
    }

    // This was also used for part 2
    public void addFavoriteToy(Toy toy) {
        favoriteToys.add(toy);
    }

    @Override
    public String toString() {
        StringBuilder makeString = new StringBuilder();
        makeString.append(String.format("{%s} the Cat is {%s}, has {%s} fur and {%s} eyes\n", this.name, this.breed, this.furColor, this.eyeColor));
        if (favoriteToys.isEmpty()) {
            makeString.append("This cat does not have any favorite toys.\n");
        } else {
            makeString.append("Favorite Toys:\n");
            for (Toy toy : favoriteToys) {
                makeString.append(String.format("\t{%s}, {%s} color\n", toy.getToyName(), toy.getToyColor()));
            }
        }
        return makeString.toString();
    }
}
