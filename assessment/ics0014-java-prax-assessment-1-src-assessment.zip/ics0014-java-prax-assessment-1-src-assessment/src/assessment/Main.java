package src.assessment;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.stream.Collectors;

public class Main {
    /*
    !!!
    This code was for the part 2
    !!!

    public static void main(String[] args) {
        List<Cat> catList = new ArrayList<>();

        // Random toys
        Toy toy1 = new Toy("Ball", "Red");
        Toy toy2 = new Toy("Mouse", "Gray");
        Toy toy3 = new Toy("Feather", "White");

        // Creating cats and toys
        Cat cat1 = new Cat("Fluffy", "British Short Hair", "Blue", "Red");
        cat1.addFavoriteToy(toy1);
        cat1.addFavoriteToy(toy2);
        catList.add(cat1);

        Cat cat2 = new Cat("Meowling", "Scottish Short Hair", "Brown", "Green");
        cat2.addFavoriteToy(toy3);
        catList.add(cat2);

        // Printing cats
        for (Cat cat : catList) {
            System.out.println(cat);
        }
    }
     */
    private static final List<String> CAT_NAMES = List.of(
            "Whiskers",
            "Smokey",
            "Luna",
            "Oreo",
            "Simba",
            "Mittens",
            "Shadow",
            "Tigger",
            "Lucy",
            "Chloe",
            "Milo",
            "Cleo",
            "Leo",
            "Bella",
            "Max",
            "Ginger",
            "Felix",
            "Charlie",
            "Lily",
            "Ziggy"
    );
    private static final List<String> CAT_BREEDS = List.of(
            "Siamese",
            "Maine Coon",
            "Persian",
            "Sphynx",
            "Bengal",
            "Ragdoll",
            "British Shorthair",
            "Scottish Fold",
            "Norwegian Forest",
            "Russian Blue"
    );
    private static final List<String> CAT_FUR_COLORS = List.of(
            "Black",
            "White",
            "Gray",
            "Brown",
            "Orange",
            "Calico",
            "Tabby",
            "Tortoiseshell",
            "Cream",
            "Blue"
    );
    private static final List<String> CAT_EYE_COLORS = List.of(
            "Green",
            "Blue",
            "Yellow",
            "Amber",
            "Hazel",
            "Golden",
            "Copper",
            "Gray",
            "Brown",
            "Orange"
    );
    private static final List<String> TOY_NAMES = List.of(
            "Ball",
            "Mouse",
            "Feather",
            "String",
            "Yarn",
            "Fishing Rod",
            "Squeaky Toy",
            "Catnip Mouse",
            "Scratching Post",
            "Tunnel",
            "Chew Toy",
            "Frisbee",
            "Interactive Toy",
            "Rope",
            "Rubber Duck",
            "Plush Toy",
            "Bell Ball",
            "Teaser Wand",
            "Treat Dispenser",
            "Laser Pointer"
    );
    private static final List<String> TOY_COLORS = List.of(
            "Red",
            "Blue",
            "Green",
            "Yellow",
            "Purple",
            "Orange",
            "Pink",
            "Black",
            "White",
            "Brown"
    );

    // Found a much easier way to group them by using the Collectors method
    public static Map<String, List<Cat>> groupCatsByEyeColor(List<Cat> cats) {
        return cats.stream()
                .collect(Collectors.groupingBy(Cat::getEyeColor));
    }
    public static Map<String, List<Cat>> groupCatsByBreed(List<Cat> cats) {
        return cats.stream()
                .collect(Collectors.groupingBy(Cat::getBreed));
    }

    // This just loops through all toys for all cats and puts them in a list
    public static List<Cat> catFavoriteToyList(List<Cat> cats, String toyName) {
        List<Cat> catsWithToy = new ArrayList<>();
        for (Cat cat : cats) {
            for (Toy toy : cat.getFavoriteToys()) {
                if (toy.getToyName().equals(toyName)) {
                    catsWithToy.add(cat);
                    break;
                }
            }
        }
        return catsWithToy;
    }

    /* This one was the hardest one, because I think we did not do it in the lesson. I read that HashSet
    should be able to remove duplicates, but I did not know how to use it correctly.
    I think removing duplicates after should also work. I am not 100% sure if this code is correct.
     */
    public static List<Toy> getAllFavoriteToys(List<Cat> cats) {
        List<Toy> allToys = new ArrayList<>();
        for (Cat cat : cats) {
            for (Toy toy : cat.getFavoriteToys()) {
                if (!allToys.contains(toy)) {
                    allToys.add(toy);
                }
            }
        }
        // Removing duplicates
        ArrayList<Toy> listWithoutDuplicates = new ArrayList<>();
        for (Toy element : allToys) {
            if (!listWithoutDuplicates.contains(element)) {
                listWithoutDuplicates.add(element);
            }
        }

        return listWithoutDuplicates;
    }

    /* Here I used the same Collectors method, but just added a switch statement, hopefully works :D
    Here I of course hope that the user knows what propertyNames are there.
     */
    public static List<Cat> filterCatsByProperty(List<Cat> cats, String propertyName, String propertyValue) {
        return cats.stream()
                .filter(cat -> {
                    switch (propertyName) {
                        case "name":
                            return cat.getName().equals(propertyValue);
                        case "breed":
                            return cat.getBreed().equals(propertyValue);
                        case "furColor":
                            return cat.getFurColor().equals(propertyValue);
                        case "eyeColor":
                            return cat.getEyeColor().equals(propertyValue);
                        default:
                            return false;
                    }
                })
                .collect(Collectors.toList());
    }
    public static void main(String[] args) {
        List<Cat> catList = new ArrayList<>();

        // Create random 10 cats
        Random random = new Random();
        for (int i = 0; i < 10; i++) {
            String name = CAT_NAMES.get(random.nextInt(CAT_NAMES.size()));
            String breed = CAT_BREEDS.get(random.nextInt(CAT_BREEDS.size()));
            String furColor = CAT_FUR_COLORS.get(random.nextInt(CAT_FUR_COLORS.size()));
            String eyeColor = CAT_EYE_COLORS.get(random.nextInt(CAT_EYE_COLORS.size()));

            // Generate random number of favorite toys for each cat, maximum of 5 toys
            int numToys = random.nextInt(5);
            List<Toy> favoriteToys = new ArrayList<>();
            for (int j = 0; j < numToys; j++) {
                String toyName = TOY_NAMES.get(random.nextInt(TOY_NAMES.size()));
                String toyColor = TOY_COLORS.get(random.nextInt(TOY_COLORS.size()));
                favoriteToys.add(new Toy(toyName, toyColor));
            }

            Cat cat = new Cat(name, breed, furColor, eyeColor, favoriteToys);
            catList.add(cat);
        }

        // Print the list of cats
        for (Cat cat : catList) {
            System.out.println(cat);
        }
        System.out.println("\n \n");

        // Map by eye color
        Map<String, List<Cat>> catsByEyeColor = groupCatsByEyeColor(catList);
        for (Map.Entry<String, List<Cat>> entry : catsByEyeColor.entrySet()) {
            System.out.println(entry.getKey());
            for (Cat cat : entry.getValue()) {
                System.out.println("\t" + cat.getName());
            }
        }
        System.out.println("\n \n");

        // Map by breed
        Map<String, List<Cat>> catsByBreed = groupCatsByBreed(catList);
        for (Map.Entry<String, List<Cat>> entry : catsByBreed.entrySet()) {
            System.out.println(entry.getKey());
            for (Cat cat : entry.getValue()) {
                System.out.println("\t" + cat.getName());
            }
        }
        System.out.println("\n \n");

        // Cat favorite toy list example
        List<Cat> catsWithBallToy = catFavoriteToyList(catList, "Ball");
        System.out.println("Cats with Ball as favorite toy:");
        for (Cat cat : catsWithBallToy) {
            System.out.println(cat.getName());
        }
        System.out.println("\n \n");

        // All favorite toys example
        List<Toy> allFavoriteToys = getAllFavoriteToys(catList);
        System.out.println("All favorite toys:");
        for (Toy toy : allFavoriteToys) {
            System.out.println(toy.getToyName());
        }
        System.out.println("\n \n");

        // Example for last method, filter cats by breed Siamese
        List<Cat> filteredCatsByBreed = filterCatsByProperty(catList, "breed", "Siamese");
        System.out.println("Filtered cats:");
        for (Cat cat : filteredCatsByBreed) {
            System.out.println(cat.getName());
        }
    }
}
